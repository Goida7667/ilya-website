Write-Host "========================================" -ForegroundColor Cyan
Write-Host "    Установка и запуск сайта для Илюхи" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Проверка Node.js
Write-Host "Проверка Node.js..." -ForegroundColor Yellow
try {
    $nodeVersion = node --version
    Write-Host "Node.js найден! Версия: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "Node.js не найден!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Пожалуйста, установите Node.js:" -ForegroundColor Yellow
    Write-Host "1. Перейдите на https://nodejs.org/" -ForegroundColor White
    Write-Host "2. Скачайте LTS версию" -ForegroundColor White
    Write-Host "3. Установите с настройками по умолчанию" -ForegroundColor White
    Write-Host "4. Перезапустите этот скрипт" -ForegroundColor White
    Write-Host ""
    Read-Host "Нажмите Enter для выхода"
    exit 1
}

Write-Host ""

# Установка зависимостей фронтенда
Write-Host "Установка зависимостей фронтенда..." -ForegroundColor Yellow
try {
    npm install
    Write-Host "Зависимости фронтенда установлены!" -ForegroundColor Green
} catch {
    Write-Host "Ошибка установки зависимостей фронтенда!" -ForegroundColor Red
    Read-Host "Нажмите Enter для выхода"
    exit 1
}

Write-Host ""

# Установка зависимостей бэкенда
Write-Host "Установка зависимостей бэкенда..." -ForegroundColor Yellow
try {
    Set-Location backend
    npm install
    Set-Location ..
    Write-Host "Зависимости бэкенда установлены!" -ForegroundColor Green
} catch {
    Write-Host "Ошибка установки зависимостей бэкенда!" -ForegroundColor Red
    Read-Host "Нажмите Enter для выхода"
    exit 1
}

Write-Host ""

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "    Запуск сайта" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Откроется два окна:" -ForegroundColor Yellow
Write-Host "1. Фронтенд (React) - http://localhost:3000" -ForegroundColor White
Write-Host "2. Бэкенд (Node.js) - http://localhost:3001" -ForegroundColor White
Write-Host ""
Write-Host "Для остановки нажмите Ctrl+C в каждом окне" -ForegroundColor Yellow
Write-Host ""

# Запуск бэкенда
Write-Host "Запуск бэкенда..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD\backend'; npm run dev"

# Ожидание
Start-Sleep -Seconds 3

# Запуск фронтенда
Write-Host "Запуск фронтенда..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD'; npm run dev"

Write-Host ""
Write-Host "Сайт запущен! Откройте http://localhost:3000 в браузере" -ForegroundColor Green
Write-Host ""
Read-Host "Нажмите Enter для выхода"
