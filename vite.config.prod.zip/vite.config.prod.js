import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Конфигурация для продакшна с HTTPS
export default defineConfig({
  plugins: [react()],
  server: {
    https: true,  // HTTPS для продакшна
    host: true,
    port: 3000
  },
  build: {
    outDir: 'dist'
  }
})
