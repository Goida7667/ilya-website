# Сайт для Илюхи

Современный веб-сайт на React с Tailwind CSS, настроенный с HTTPS сертификатом и почтовым сервисом.

## 🚀 Технологии

- **Frontend**: React 18 + Vite
- **Стили**: Tailwind CSS
- **Роутинг**: React Router
- **Backend**: Node.js + Express
- **Почта**: Nodemailer + различные провайдеры
- **SSL**: Let's Encrypt / Cloudflare
- **Деплой**: Docker + Nginx

## 📦 Установка

### 1. Клонирование и установка зависимостей

```bash
# Установка зависимостей фронтенда
npm install

# Установка зависимостей бэкенда
cd backend
npm install
cd ..
```

### 2. Настройка переменных окружения

Скопируйте `env.example` в `.env` и настройте:

```bash
cp env.example .env
```

Отредактируйте `.env`:
```env
# Домен сайта
VITE_DOMAIN=yourdomain.com

# Email настройки
VITE_EMAIL_SERVICE=smtp
VITE_EMAIL_API_KEY=your-api-key

# SSL сертификат
SSL_CERT_PATH=./ssl/cert.pem
SSL_KEY_PATH=./ssl/private.key
```

### 3. Настройка почты

Создайте файл `backend/.env`:
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@yourdomain.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@yourdomain.com
```

## 🏃‍♂️ Запуск

### Режим разработки

```bash
# Запуск фронтенда
npm run dev

# В другом терминале - запуск бэкенда
cd backend
npm run dev
```

### Продакшн

```bash
# Сборка фронтенда
npm run build

# Запуск с Docker
docker-compose up -d

# Или запуск бэкенда отдельно
cd backend
npm start
```

## 📧 Настройка почты

Подробное руководство по настройке почты для домена находится в файле [EMAIL_SETUP_GUIDE.md](./EMAIL_SETUP_GUIDE.md).

### Быстрая настройка с Google Workspace:

1. Зарегистрируйтесь на [Google Workspace](https://workspace.google.com/)
2. Добавьте свой домен
3. Настройте DNS записи:
   ```
   MX 1 aspmx.l.google.com.
   MX 5 alt1.aspmx.l.google.com.
   MX 5 alt2.aspmx.l.google.com.
   MX 10 alt3.aspmx.l.google.com.
   MX 10 alt4.aspmx.l.google.com.
   ```
4. Создайте App Password для SMTP
5. Обновите настройки в `backend/.env`

## 🔒 Настройка HTTPS

### Вариант 1: Let's Encrypt

```bash
# Установка Certbot
sudo apt update
sudo apt install certbot

# Получение сертификата
sudo certbot certonly --standalone -d yourdomain.com

# Обновление nginx.conf с путями к сертификатам
```

### Вариант 2: Cloudflare

1. Добавьте домен в Cloudflare
2. Включите "Full (strict)" SSL режим
3. Настройте Origin Certificates

## 🐳 Docker

### Запуск с Docker Compose

```bash
# Сборка и запуск
docker-compose up -d

# Просмотр логов
docker-compose logs -f

# Остановка
docker-compose down
```

### Настройка Nginx

Обновите `nginx.conf` с вашим доменом и путями к SSL сертификатам.

## 📁 Структура проекта

```
├── src/
│   ├── components/          # React компоненты
│   ├── pages/              # Страницы
│   ├── services/           # Сервисы (email, API)
│   └── main.jsx           # Точка входа
├── backend/               # Node.js сервер
├── public/                # Статические файлы
├── nginx.conf            # Конфигурация Nginx
├── docker-compose.yml    # Docker конфигурация
└── EMAIL_SETUP_GUIDE.md  # Руководство по почте
```

## 🛠️ Доступные команды

```bash
# Фронтенд
npm run dev          # Запуск dev сервера
npm run build        # Сборка для продакшна
npm run preview      # Предварительный просмотр сборки
npm run lint         # Проверка кода

# Бэкенд
cd backend
npm start           # Запуск продакшн сервера
npm run dev         # Запуск dev сервера с nodemon
```

## 🌐 Деплой

### 1. Подготовка сервера

```bash
# Обновление системы
sudo apt update && sudo apt upgrade -y

# Установка Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Установка Docker Compose
sudo apt install docker-compose -y
```

### 2. Загрузка проекта

```bash
# Клонирование репозитория
git clone <your-repo-url>
cd ilya-website

# Настройка переменных окружения
cp env.example .env
# Отредактируйте .env файл
```

### 3. Настройка домена и SSL

```bash
# Получение SSL сертификата
sudo certbot certonly --standalone -d yourdomain.com

# Обновление nginx.conf с путями к сертификатам
```

### 4. Запуск

```bash
# Сборка и запуск
docker-compose up -d

# Проверка статуса
docker-compose ps
```

## 📞 Поддержка

Если у вас возникли вопросы по настройке:

1. Проверьте [EMAIL_SETUP_GUIDE.md](./EMAIL_SETUP_GUIDE.md) для настройки почты
2. Убедитесь, что все переменные окружения настроены правильно
3. Проверьте логи: `docker-compose logs -f`

## 📄 Лицензия

MIT License - используйте свободно для личных и коммерческих проектов.
