# Руководство по настройке почты для домена

## Обзор

Этот документ описывает различные способы настройки почты для вашего домена с HTTPS сертификатом.

## Варианты настройки почты

### 1. Google Workspace (Рекомендуется)

**Преимущества:**
- Надежный сервис от Google
- Простая настройка
- Интеграция с Gmail
- Профессиональный вид

**Шаги настройки:**
1. Перейдите на [Google Workspace](https://workspace.google.com/)
2. Выберите план (начните с Business Starter)
3. Зарегистрируйте свой домен
4. Подтвердите владение доменом через DNS записи
5. Настройте MX записи в DNS

**DNS записи для Google Workspace:**
```
MX 1 aspmx.l.google.com.
MX 5 alt1.aspmx.l.google.com.
MX 5 alt2.aspmx.l.google.com.
MX 10 alt3.aspmx.l.google.com.
MX 10 alt4.aspmx.l.google.com.
```

### 2. Microsoft 365

**Преимущества:**
- Интеграция с Office 365
- Хорошая безопасность
- Поддержка Exchange

**Шаги настройки:**
1. Перейдите на [Microsoft 365](https://www.microsoft.com/microsoft-365)
2. Выберите план Business Basic или выше
3. Добавьте свой домен
4. Подтвердите домен через DNS
5. Настройте MX записи

### 3. Zoho Mail

**Преимущества:**
- Бесплатный план до 5 пользователей
- Хорошая функциональность
- Простая настройка

**Шаги настройки:**
1. Перейдите на [Zoho Mail](https://www.zoho.com/mail/)
2. Выберите план (начните с бесплатного)
3. Добавьте свой домен
4. Подтвердите через DNS
5. Настройте MX записи

**DNS записи для Zoho Mail:**
```
MX 10 mx.zoho.com.
MX 20 mx2.zoho.com.
MX 50 mx3.zoho.com.
```

### 4. Yandex 360

**Преимущества:**
- Российский сервис
- Бесплатный план
- Хорошая поддержка русского языка

**Шаги настройки:**
1. Перейдите на [Yandex 360](https://360.yandex.ru/)
2. Выберите бесплатный план
3. Добавьте свой домен
4. Подтвердите через DNS
5. Настройте MX записи

## Настройка DNS записей

### Обязательные записи

1. **MX записи** - для получения почты
2. **TXT записи** - для подтверждения домена
3. **CNAME записи** - для веб-интерфейса почты

### Пример настройки для Google Workspace

```
# MX записи (приоритет важен)
MX 1 aspmx.l.google.com.
MX 5 alt1.aspmx.l.google.com.
MX 5 alt2.aspmx.l.google.com.
MX 10 alt3.aspmx.l.google.com.
MX 10 alt4.aspmx.l.google.com.

# TXT записи для подтверждения
TXT google-site-verification=YOUR_VERIFICATION_CODE

# CNAME для веб-интерфейса
CNAME mail yourdomain.com.
```

## Настройка SSL сертификата для почты

### 1. Let's Encrypt (Бесплатно)

```bash
# Установка Certbot
sudo apt update
sudo apt install certbot

# Получение сертификата
sudo certbot certonly --standalone -d yourdomain.com -d mail.yourdomain.com

# Автообновление
sudo crontab -e
# Добавить: 0 12 * * * /usr/bin/certbot renew --quiet
```

### 2. Cloudflare SSL

1. Добавьте домен в Cloudflare
2. Включите "Full (strict)" SSL режим
3. Настройте Origin Certificates для сервера

## Настройка почтового сервера

### Использование Docker с Postfix

```yaml
# docker-compose.yml
version: '3.8'
services:
  mailserver:
    image: mailserver/docker-mailserver:latest
    hostname: mail.yourdomain.com
    domainname: yourdomain.com
    container_name: mailserver
    ports:
      - "25:25"
      - "143:143"
      - "587:587"
      - "993:993"
    volumes:
      - ./maildata:/var/mail
      - ./mailstate:/var/mail-state
      - ./config:/tmp/docker-mailserver
      - ./ssl:/etc/ssl/mailserver
    environment:
      - ENABLE_SPAMASSASSIN=1
      - ENABLE_CLAMAV=1
      - ENABLE_FAIL2BAN=1
      - ENABLE_POSTGREY=1
      - ENABLE_MANAGESIEVE=1
      - ONE_DIR=1
      - DMS_DEBUG=0
      - SSL_TYPE=letsencrypt
    restart: unless-stopped
```

## Настройка в коде

### 1. Переменные окружения

Создайте файл `.env` в корне проекта:

```env
# Email настройки
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@yourdomain.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@yourdomain.com

# Домен
DOMAIN=yourdomain.com
```

### 2. Обновление Contact формы

```javascript
// src/pages/Contact.jsx
import emailService from '../services/emailService'

const handleSubmit = async (e) => {
  e.preventDefault()
  
  try {
    await emailService.sendEmail({
      to: 'info@yourdomain.com',
      subject: `Сообщение от ${formData.name}`,
      text: formData.message,
      html: `
        <h3>Новое сообщение с сайта</h3>
        <p><strong>Имя:</strong> ${formData.name}</p>
        <p><strong>Email:</strong> ${formData.email}</p>
        <p><strong>Сообщение:</strong></p>
        <p>${formData.message}</p>
      `
    })
    
    alert('Сообщение отправлено успешно!')
    setFormData({ name: '', email: '', message: '' })
  } catch (error) {
    alert('Ошибка отправки сообщения. Попробуйте позже.')
  }
}
```

## Проверка настройки

### 1. Проверка MX записей

```bash
# Linux/Mac
dig MX yourdomain.com

# Windows
nslookup -type=MX yourdomain.com
```

### 2. Проверка SSL сертификата

```bash
# Проверка сертификата
openssl s_client -connect mail.yourdomain.com:993 -starttls imap

# Проверка веб-сертификата
openssl s_client -connect yourdomain.com:443
```

### 3. Тестирование отправки

```javascript
// Тестовый скрипт
const testEmail = async () => {
  try {
    await emailService.sendEmail({
      to: 'test@yourdomain.com',
      subject: 'Тестовое сообщение',
      text: 'Это тестовое сообщение для проверки настройки почты.'
    })
    console.log('Email отправлен успешно!')
  } catch (error) {
    console.error('Ошибка:', error)
  }
}
```

## Рекомендации по безопасности

1. **Используйте App Passwords** вместо обычных паролей
2. **Включите 2FA** для всех почтовых аккаунтов
3. **Настройте SPF, DKIM, DMARC** записи
4. **Регулярно обновляйте** SSL сертификаты
5. **Мониторьте** логи почтового сервера

## SPF, DKIM, DMARC настройки

### SPF запись
```
TXT "v=spf1 include:_spf.google.com ~all"
```

### DKIM (для Google Workspace)
```
TXT "v=DKIM1; k=rsa; p=YOUR_DKIM_PUBLIC_KEY"
```

### DMARC
```
TXT "v=DMARC1; p=quarantine; rua=mailto:dmarc@yourdomain.com"
```

## Заключение

Выберите подходящий вариант настройки почты в зависимости от ваших потребностей:

- **Для простого использования**: Yandex 360 или Zoho Mail
- **Для бизнеса**: Google Workspace или Microsoft 365
- **Для полного контроля**: Собственный почтовый сервер

Все варианты поддерживают HTTPS и могут быть интегрированы с вашим React сайтом.
