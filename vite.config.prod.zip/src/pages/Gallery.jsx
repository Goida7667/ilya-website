import React, { useState } from 'react'

const Gallery = () => {
  const [currentImage, setCurrentImage] = useState(0)

  // Примеры изображений (замените на реальные)
  const images = [
    {
      id: 1,
      src: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=600&fit=crop',
      alt: 'Илья в офисе',
      title: 'Рабочий день',
      description: 'Илья за работой в современном офисе'
    },
    {
      id: 2,
      src: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=800&h=600&fit=crop',
      alt: 'Илья на встрече',
      title: 'Деловая встреча',
      description: 'Важная презентация проекта'
    },
    {
      id: 3,
      src: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=800&h=600&fit=crop',
      alt: 'Илья с командой',
      title: 'Командная работа',
      description: 'Совместная работа над проектом'
    },
    {
      id: 4,
      src: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=800&h=600&fit=crop',
      alt: 'Илья на отдыхе',
      title: 'Время отдыха',
      description: 'Моменты расслабления и отдыха'
    },
    {
      id: 5,
      src: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=800&h=600&fit=crop',
      alt: 'Илья с семьей',
      title: 'Семейные моменты',
      description: 'Дорогие сердцу семейные фотографии'
    },
    {
      id: 6,
      src: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=600&fit=crop',
      alt: 'Илья на природе',
      title: 'Природа и спорт',
      description: 'Активный отдых на свежем воздухе'
    }
  ]

  const nextImage = () => {
    setCurrentImage((prev) => (prev + 1) % images.length)
  }

  const prevImage = () => {
    setCurrentImage((prev) => (prev - 1 + images.length) % images.length)
  }

  const goToImage = (index) => {
    setCurrentImage(index)
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Галерея Ильи
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Моменты из жизни, работы и увлечений Ильи
        </p>
      </div>

      {/* Основная карусель */}
      <div className="relative max-w-4xl mx-auto mb-8">
        <div className="relative overflow-hidden rounded-lg shadow-2xl">
          <div className="relative h-96 md:h-[500px]">
            <img
              src={images[currentImage].src}
              alt={images[currentImage].alt}
              className="w-full h-full object-cover transition-transform duration-500"
            />
            
            {/* Информация об изображении */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
              <h3 className="text-2xl font-bold text-white mb-2">
                {images[currentImage].title}
              </h3>
              <p className="text-gray-200">
                {images[currentImage].description}
              </p>
            </div>
          </div>

          {/* Кнопки навигации */}
          <button
            onClick={prevImage}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 rounded-full p-3 shadow-lg transition-all duration-200"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <button
            onClick={nextImage}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 rounded-full p-3 shadow-lg transition-all duration-200"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>

        {/* Индикаторы */}
        <div className="flex justify-center mt-4 space-x-2">
          {images.map((_, index) => (
            <button
              key={index}
              onClick={() => goToImage(index)}
              className={`w-3 h-3 rounded-full transition-all duration-200 ${
                index === currentImage
                  ? 'bg-primary-600 scale-125'
                  : 'bg-gray-300 hover:bg-gray-400'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Миниатюры */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 max-w-4xl mx-auto">
        {images.map((image, index) => (
          <button
            key={image.id}
            onClick={() => goToImage(index)}
            className={`relative overflow-hidden rounded-lg shadow-md transition-all duration-200 ${
              index === currentImage
                ? 'ring-4 ring-primary-500 scale-105'
                : 'hover:scale-105'
            }`}
          >
            <img
              src={image.src}
              alt={image.alt}
              className="w-full h-24 object-cover"
            />
            <div className="absolute inset-0 bg-black/0 hover:bg-black/20 transition-colors duration-200" />
          </button>
        ))}
      </div>

      {/* Статистика */}
      <div className="mt-12 text-center">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-2xl mx-auto">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="text-3xl font-bold text-primary-600 mb-2">
              {images.length}
            </div>
            <div className="text-gray-600">Фотографий</div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="text-3xl font-bold text-primary-600 mb-2">
              2024
            </div>
            <div className="text-gray-600">Год создания</div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="text-3xl font-bold text-primary-600 mb-2">
              100%
            </div>
            <div className="text-gray-600">Качество</div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Gallery
