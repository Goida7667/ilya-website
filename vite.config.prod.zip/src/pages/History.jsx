import React from 'react'

const History = () => {
  const timeline = [
    {
      year: '2020',
      title: 'Начало карьеры',
      description: 'Илья начал свой профессиональный путь в сфере IT, изучая основы программирования и веб-разработки.',
      icon: '🎓',
      color: 'bg-blue-500'
    },
    {
      year: '2021',
      title: 'Первый проект',
      description: 'Создал свой первый серьезный веб-проект, который получил положительные отзывы от клиентов.',
      icon: '🚀',
      color: 'bg-green-500'
    },
    {
      year: '2022',
      title: 'Расширение навыков',
      description: 'Изучил современные фреймворки и технологии, включая React, Node.js и облачные сервисы.',
      icon: '💻',
      color: 'bg-purple-500'
    },
    {
      year: '2023',
      title: 'Командная работа',
      description: 'Присоединился к команде разработчиков, где работал над крупными корпоративными проектами.',
      icon: '👥',
      color: 'bg-orange-500'
    },
    {
      year: '2024',
      title: 'Личный бренд',
      description: 'Создал собственный сайт и начал развивать личный бренд в сфере веб-разработки.',
      icon: '⭐',
      color: 'bg-red-500'
    }
  ]

  const achievements = [
    {
      title: 'Веб-разработка',
      level: 95,
      description: 'Создание современных веб-приложений'
    },
    {
      title: 'JavaScript',
      level: 90,
      description: 'Продвинутое знание языка программирования'
    },
    {
      title: 'React',
      level: 88,
      description: 'Разработка пользовательских интерфейсов'
    },
    {
      title: 'Node.js',
      level: 85,
      description: 'Серверная разработка и API'
    },
    {
      title: 'Дизайн',
      level: 80,
      description: 'Создание красивых и функциональных интерфейсов'
    }
  ]

  const interests = [
    {
      title: 'Программирование',
      description: 'Страсть к созданию инновационных решений',
      icon: '💻'
    },
    {
      title: 'Спорт',
      description: 'Активный образ жизни и физическая активность',
      icon: '🏃‍♂️'
    },
    {
      title: 'Путешествия',
      description: 'Изучение новых культур и мест',
      icon: '✈️'
    },
    {
      title: 'Фотография',
      description: 'Запечатление важных моментов жизни',
      icon: '📸'
    },
    {
      title: 'Музыка',
      description: 'Игра на гитаре и создание мелодий',
      icon: '🎸'
    },
    {
      title: 'Чтение',
      description: 'Постоянное самообразование и развитие',
      icon: '📚'
    }
  ]

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Заголовок */}
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          История Ильи
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Путь развития, достижения и увлечения за последние годы
        </p>
      </div>

      {/* Временная шкала */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Временная шкала
        </h2>
        <div className="relative">
          {/* Линия времени */}
          <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gray-200"></div>
          
          <div className="space-y-12">
            {timeline.map((item, index) => (
              <div key={item.year} className={`flex items-center ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                {/* Содержимое */}
                <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8 text-left'}`}>
                  <div className="bg-white p-6 rounded-lg shadow-lg">
                    <div className="flex items-center mb-4">
                      <span className="text-4xl mr-3">{item.icon}</span>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">{item.title}</h3>
                        <p className="text-primary-600 font-semibold">{item.year}</p>
                      </div>
                    </div>
                    <p className="text-gray-600">{item.description}</p>
                  </div>
                </div>

                {/* Точка на линии */}
                <div className="relative z-10">
                  <div className={`w-4 h-4 rounded-full ${item.color} border-4 border-white shadow-lg`}></div>
                </div>

                {/* Пустое место */}
                <div className="w-1/2"></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Навыки */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Навыки и компетенции
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {achievements.map((skill, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-lg">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-lg font-semibold text-gray-900">{skill.title}</h3>
                <span className="text-sm font-medium text-primary-600">{skill.level}%</span>
              </div>
              <p className="text-gray-600 text-sm mb-4">{skill.description}</p>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-primary-600 h-2 rounded-full transition-all duration-1000 ease-out"
                  style={{ width: `${skill.level}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Увлечения */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Увлечения и интересы
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {interests.map((interest, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-200">
              <div className="text-center">
                <div className="text-4xl mb-4">{interest.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{interest.title}</h3>
                <p className="text-gray-600">{interest.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Цитата */}
      <div className="bg-gradient-to-r from-primary-500 to-primary-600 rounded-lg p-8 text-center text-white">
        <blockquote className="text-xl md:text-2xl font-medium mb-4">
          "Успех — это не конечная точка, а постоянное стремление к совершенству и развитию."
        </blockquote>
        <cite className="text-lg opacity-90">— Илья</cite>
      </div>

      {/* Статистика */}
      <div className="mt-16">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Достижения в цифрах
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="text-center">
            <div className="text-4xl font-bold text-primary-600 mb-2">5+</div>
            <div className="text-gray-600">Лет опыта</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-primary-600 mb-2">50+</div>
            <div className="text-gray-600">Проектов</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-primary-600 mb-2">100%</div>
            <div className="text-gray-600">Довольных клиентов</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-primary-600 mb-2">24/7</div>
            <div className="text-gray-600">Доступность</div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default History
