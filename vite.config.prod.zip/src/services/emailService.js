// Сервис для отправки email
class EmailService {
  constructor() {
    this.apiKey = import.meta.env.VITE_EMAIL_API_KEY
    this.service = import.meta.env.VITE_EMAIL_SERVICE || 'smtp'
  }

  // Отправка email через различные сервисы
  async sendEmail({ to, subject, text, html }) {
    try {
      switch (this.service) {
        case 'smtp':
          return await this.sendViaSMTP({ to, subject, text, html })
        case 'sendgrid':
          return await this.sendViaSendGrid({ to, subject, text, html })
        case 'mailgun':
          return await this.sendViaMailgun({ to, subject, text, html })
        case 'nodemailer':
          return await this.sendViaNodemailer({ to, subject, text, html })
        default:
          throw new Error('Неподдерживаемый email сервис')
      }
    } catch (error) {
      console.error('Ошибка отправки email:', error)
      throw error
    }
  }

  // Отправка через SMTP (требует backend)
  async sendViaSMTP({ to, subject, text, html }) {
    const response = await fetch('/api/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ to, subject, text, html })
    })

    if (!response.ok) {
      throw new Error('Ошибка отправки email через SMTP')
    }

    return await response.json()
  }

  // Отправка через SendGrid
  async sendViaSendGrid({ to, subject, text, html }) {
    const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        personalizations: [{
          to: [{ email: to }]
        }],
        from: { email: 'noreply@yourdomain.com' },
        subject: subject,
        content: [
          { type: 'text/plain', value: text },
          { type: 'text/html', value: html }
        ]
      })
    })

    if (!response.ok) {
      throw new Error('Ошибка отправки email через SendGrid')
    }

    return { success: true }
  }

  // Отправка через Mailgun
  async sendViaMailgun({ to, subject, text, html }) {
    const formData = new FormData()
    formData.append('from', 'noreply@yourdomain.com')
    formData.append('to', to)
    formData.append('subject', subject)
    formData.append('text', text)
    formData.append('html', html)

    const response = await fetch(`https://api.mailgun.net/v3/yourdomain.com/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${btoa(`api:${this.apiKey}`)}`
      },
      body: formData
    })

    if (!response.ok) {
      throw new Error('Ошибка отправки email через Mailgun')
    }

    return await response.json()
  }

  // Отправка через Nodemailer (требует backend)
  async sendViaNodemailer({ to, subject, text, html }) {
    const response = await fetch('/api/send-email-nodemailer', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ to, subject, text, html })
    })

    if (!response.ok) {
      throw new Error('Ошибка отправки email через Nodemailer')
    }

    return await response.json()
  }
}

export default new EmailService()
